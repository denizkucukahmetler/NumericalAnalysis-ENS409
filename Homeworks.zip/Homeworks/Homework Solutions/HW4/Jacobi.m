function [solution, iter] = Jacobi(A,b,x0,t)

    n=size(x0);
    n = n(1);


    criterion=10000000000; 

    solution = zeros(1,n);
    iter = 0;
    prev_solution = solution;
    while criterion>t
        if iter>100000000000
            break
        end
        
        for i=1:n
            summ=0;
            for j=1:n
                if j==i
                    
                else 
                summ=summ+A(i,j)*solution(j);
                end
            end
            solution(i)=(1/A(i,i))*(b(i)-summ);
        end

        criterion=sum(abs(prev_solution-solution));
        iter = iter + 1;
        prev_solution = solution;
    end
    solution = solution';
end

