function solution = LU_Decomposition(A,b)
    [L, U] = lu(A);

    first_el = GaussianElimination(L, b);
    solution = GaussianElimination(U, first_el);
end

