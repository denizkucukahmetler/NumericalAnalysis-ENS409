function solution = GaussianElimination(A,b)

    steps = size(A);
    steps = steps(1);
    
    for i = 1:(steps-1)
        for j = steps:-1:i+1
            
            rhs = A(i,i);
            lhs = A(j,i);
            res = lhs/rhs;
            A(j,:) = A(j,:) - res*A(i,:);
            b(j) = b(j) - res*b(i);
            
        end
    end 
    
    solution = zeros(1,steps);
    solution(steps) = b(steps)/A(steps,steps);        
    for i = steps-1:-1:1                    
        total = 0;
        for k = steps:-1:i+1                
            total = total + A(i,k)*solution(k);    
        end 
        solution(i) = (b(i)- total)/A(i,i);
    end 
    
    solution = solution';
end

