function [solution, iter] = GaussSeidel(A,b,x0,t)
   
    criterion = 10000;

    iter = 0;
    solution = x0;
    n = size(x0,1);
    
    while criterion>t
        if iter>10000000
            break
        end
        prev_sol=solution;
        for i=1:n  
            summ=0;

            for j=1:i-1
               summ=summ+A(i,j)*solution(j);
            end

            for j=i+1:n
               summ=summ+A(i,j)*prev_sol(j);
            end
            ft = (1/A(i,i));
            st = (b(i)-summ);
            solution(i)=ft*st;
        end

        criterion=sqrt(sum((prev_sol-solution).^2));

        iter=iter+1;
    
    end
    
    
end

