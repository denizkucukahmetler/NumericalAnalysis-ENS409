


%% Problem 1

A = [1 -1 1 -1; -1 3 -3 3; 2 -4 7 -7; 3 7 -10 14];
b = [0; 2; -2; -8];
x_act = A \ b;
x0 = [0 0 -0.5 -0.5]';
tolerance = 1E-6;


x1_GE = GaussianElimination(A, b);
    disp("Solution of Gaussian Elimination:");

disp(x1_GE);
x1_LU = LU_Decomposition(A, b);

disp("Solution of LU decomposition:");
disp(x1_LU);

x1_GS = GaussSeidel(A,b,x0,tolerance);

disp("Solution of Gauss-Seidel:");
disp(x1_GS);
x1_J = Jacobi(A,b,x0,tolerance);
disp("Solution of Jacobi:");
disp(x1_J);

disp("Solution");
disp(x_act);

%% Problem 2
m_list = [9];
tolerance = 10^-4;

gs_iters = [];
j_iters = [];
for m=m_list
    
    x0 = zeros(m,1);
    A = rand(m,m);
    b = rand(m,1);
    A_inv = 1\A;
    x_act = A\b;
    disp("m = "+num2str(m));
    x2_GE = GaussianElimination(A, b);

    x2_LU = LU_Decomposition(A, b);

    [x2_GS,iter2GS] = GaussSeidel(A,b,x0,tolerance);

    [x2_J,iter2J]= Jacobi(A,b,x0,tolerance);

    gs_iters(end+1) = iter2GS;
    j_iters(end+1) = iter2J;

    disp("Solution of Gaussian Elimination:");
    x2_GE
    disp("Solution of LU decomposition:");
    x2_LU
    disp("Solution of Gauss-Seidel:");
    x2_GS
    disp("Solution of Jacobi:");
    x2_J
    disp("Actual Results:");
    x_act
    disp("Inverse of A:");
    A_inv
    fprintf("\n\n\n");

end

%% Problem 3

m_list = [];
ms = [];
tolerance = 10^-6;
gs_iters = [];
j_iters = [];
for i = 1:2:15
    m = i*5;
ms(end+1) = m;
    x0 = zeros(m,1);

    b = zeros(m,1);
    b(1) = 1;
    b(end) = 1;

    one_diag = ones(m,1);
    one_diag = -1.*one_diag;
    A = spdiags([one_diag -2*one_diag one_diag],-1:1,m,m);
    A = full(A);

    disp("m = "+num2str(m));
    x2_GE = GaussianElimination(A, b);


    x2_LU = LU_Decomposition(A, b);


    [x2_GS,iter2GS] = GaussSeidel(A,b,x0,tolerance);
    gs_iters(end+1) = iter2GS;

    [x2_J,iter2J]= Jacobi(A,b,x0,tolerance);

    j_iters(end+1) = iter2J;
    disp("Solution of Gaussian Elimination:");
    x2_GE
    disp("Solution of LU decomposition:");
    x2_LU
    disp("Solution of Gauss-Seidel:");
    x2_GS
    disp("Solution of Jacobi:");
    x2_J
    disp("Actual Results:");
    x_act
    disp("Inverse of A:");
    A_inv
    fprintf("\n\n\n");
end


figure
subplot(1,2,1)
scatter(ms,gs_iters)
title("Gauss-Seidel")
subplot(1,2,2)
scatter(ms,j_iters)
title("Jacobi")

