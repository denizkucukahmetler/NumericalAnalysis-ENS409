function diff = Richardson(f,x,df,h,n)


N = zeros(n,n);
for m=1:n-1
    if m == 1
        if df == 'center'
            N(1,1) = CDF(f,h,x);
        elseif df == 'forward'
            N(1,1) = FDF(f,h,x); 
        elseif df == 'backward'
            N(1,1) = BDF(f,h,x);
        end
    
    else
        if df == 'center'
            N(m+1,1) = CDF(f,h,x);
        elseif df == 'forward'
            N(m+1,1) = FDF(f,h,x); 
        elseif df == 'backward'
            N(m+1,1) = BDF(f,h,x);
        end
        
        
    for k=1:m
         N(m+1, k+1) = ((N(m+1, k))+ (N(m+1, k) - N(m, k))/(4^k - 1));
    end
    h = h/2;
    end
    
    
end
diff = N(n,n);
end