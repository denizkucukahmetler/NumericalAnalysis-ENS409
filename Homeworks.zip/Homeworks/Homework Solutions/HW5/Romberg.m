function [res]  = Romberg(f, a, b, n)
    
    R = zeros(n,n);
    h = b-a;
    R(1,1) = h/2*(f(a)+f(b));
    for k = 2:n
        
        h_prev = h;
        h = (b-a)/2^(k-1);
        total_sum = 0;
        for i=1:2^(k-2)
            total_sum = total_sum + f(a+(2*i-1)*h);
        end
        R(k,1) =1/2*( R((k-1),1) +h_prev*total_sum );
        
        
    end
    
    for k=2:n
        for j=2:n
            if(k>=j)
            R(k,j) = R(k,j-1)+ (R(k,j-1)-R(k-1,j-1))/(4^(j-1)-1);
            end
        end
    end
    res = R(n,n);
   

end