function [xs, ys] = runge_kutta_2nd(f, a, b, y0, h)

  
    n = (b-a)/h;
    x = y0;
    y = a;
    xs = [x];
    ys = [y];
    for i=1:n
        k1 = f(y,x);
        k2 = f(y+h/2, x+k1*(h/2));
  
        x = x+h*k2;
        y = y+h;
        
        xs(end+1) = x;
        ys(end+1) = y;
    end
   
end