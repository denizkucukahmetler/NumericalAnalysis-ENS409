function [xs,ys] = runge_kutta_4th(f, a, b, y0, h)

        
    n = (b-a)/h;
    x = a;
    y = y0;
    xs = [x];
    ys = [y];
    
    for i=1:n
        k1 = f(x,y);
        k2 = f(x+h/2, y+((k1*h)/2));
        k3 = f(x+h/2, y+h/2*k2);
        k4 = f(x+h, y+h*k3);
     
        x=x+h;
        y = y+((k1+2*k2+2*k3+k4)/6)*h;
        ys(end+1) = y;
    end
   