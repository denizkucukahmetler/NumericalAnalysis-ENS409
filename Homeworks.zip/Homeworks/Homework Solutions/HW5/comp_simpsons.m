function [res]  = comp_simpsons(f, a, b, n)

    h = (b-a)/n;
    xs = zeros(n,1);
    for j=1:n+1
       xs(j) = a+(j-1)*h;
    end
    res = f(xs(1))+f(xs(end));
    for j=1:(n/2-1)
        res = res + 2*f(xs(2*j+1));
    end

    for j=1:(n/2)
        res = res + 4*f(xs(2*(j)));
    end
    res = res*h/3;
end