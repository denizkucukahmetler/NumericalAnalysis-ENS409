function [diff] = BDF(f, h, x)
   diff = (f(x)-f(x-h))/h;
end