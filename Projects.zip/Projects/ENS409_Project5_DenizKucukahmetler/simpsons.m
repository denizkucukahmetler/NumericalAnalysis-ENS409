function [res]  = simpsons(f, a, b)
    h = (b-a)/2;
    x0 = a;
    x1 = x0+h;
    x2 = x0+2*h;
    res = h/3*(f(x0)+4*f(x1)+f(x2));
    
end