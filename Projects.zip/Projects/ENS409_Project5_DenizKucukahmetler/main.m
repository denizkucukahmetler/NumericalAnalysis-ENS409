%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      PART 1       %%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Question 1
t = [0:0.2:2*pi];
y =  @(t) 3*cos(t*1000);
diff_y = @(t) -3000*sin(1000*t);
%h = 0.01;
% h = 0.001;
% h = 0.0001;
h = 0.00001;
% DERIVATION
forward = [];
backward = [];
central = [];
richardson = [];
act_diff = [];
for i=t
    forward(end+1) = FDF(y, h, i);
    backward(end+1) = BDF(y, h, i);
    central(end+1) = CDF(y, h, i);
%     richardson(end+1) = Richardson(y,i,'center',h,1);
%     richardson(end+1) = Richardson(y,i,'center',h,3);
%     richardson(end+1) = Richardson(y,i,'center',h,6);
     richardson(end+1) = Richardson(y,i,'center',h,15);
    act_diff(end+1) = diff_y(i);
end 

% plot the results
hold on 
plot(forward);
plot(backward);
plot(central);
plot(richardson);
plot(act_diff);
legend('Forward Differentiation','Backward Differentiation','Central Differentiation','Richardson Extrapolation n = 15','Actual Differentiation')
hold off

%%  INTEGRATION
% a = 0, b = 6.3, c = 3
simps = [];
comp_simps = [];
trap = [];
act_int = []; 
romb = [];
int_y = @(t) (3*sin(1000*t))/1000;


for i=0:0.2:2*pi
    a = i;
    b = i+0.001;
    simps(end+1) = simpsons(y, a, b);
    n = 200;
    comp_simps(end+1) = comp_simpsons(y,a,b,n);
    trap(end+1) = trapezoidal(y, a, b);
    romb(end+1) = Romberg(y, a, b,1);
    act_int(end+1) = int_y(i);
    
end
hold on 
plot(simps);
plot(comp_simps);
plot(trap);
plot(romb)
plot(act_int);
legend('Simpson"s Integration','Composite Simpson"s Integration','Trapezoidal Integration','Romberg"s Integration','Actual Integration')
hold off

%% Question 2

f = @(x) x*sin(x); 
point = 1.2; 

syms g(t);
g(t) =  x*sin(x);
g(t) = diff(g(t));

n = [1,5,15];

forward2 = [];
backward2 = [];
central2 = [];
richardson2 = [];
act_diff2 = double(subs(g(t),point));
for i=n
    h = 10^(-i);
    forward2(end+1) = FDF(y, h, point);
    backward2(end+1) = BDF(y, h, point);
    central2(end+1) = CDF(y, h, point);
    richardson2(end+1) = Richardson(y,point,'center',h,100);
end

%errors 
err_f = [];
err_b = [];
err_c = [];
err_r = [];
for i=1:3
    err_f(end+1) = abs(act_diff2 - forward2(i)/act_diff2);
    err_b(end+1) = abs(act_diff2 - backward2(i)/act_diff2);
    err_c(end+1) = abs(act_diff2 - central2(i)/act_diff2);
    err_r(end+1) = abs(act_diff2 - richardson2(i)/act_diff2);
end

%plot the errors
hold on;
plot(err_f);
plot(err_b);
plot(err_c);
plot(err_r);
legend('Forward Differentiation Error','Backward Differentiation Error','Central Differentiation Error','Richardson Extrapolation Error');

%% Question 3

errors = [10^-1, 10^-3, 10^-6];
syms g(t);
g(t) =  ( 20*sin(t)^4+exp(t) )/(30 - 12*cos(t) + exp(t));
act_int3 = double(int(g(t), 0, 5));

f = @(x)( 20*sin(x)^4+exp(x) )/(30 - 12*cos(x) + exp(x));
error = @(app) abs(act_int3-app);

for e=errors
    err_idx = 1;
    a = 0;
    b = 5; 
    % Composite Simpson's
    n = 1;
    while 1
        app = comp_simpsons(f,a,b,n);
        apps_simp(err_idx,n) = app;
        err = error(app);
        if(err <= e)
            break
        end
        n = n+1;
    end
    disp('Composite Simpsons');
    disp(n);
    
    % Romberg's
    n = 1;
    while 1
        app = Romberg(f,a,b,n);
        apps_romb(err_idx,n) = app;
        err = error(app);
        if(err <= e)
            break
        end
        n = n+1;
    end
    disp('Rombergs');
    disp(n);
    err_idx = err_idx +1;
end

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%      PART 2       %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Question 1
y0 = 1;
h = 0.1;
syms w(t) 
y_der = @(x,y) x+y;
eqn = diff(y,t) == y+t;
cond = y(0) == 1;
ySol(t) = dsolve(eqn,cond);

real_sol = ySol(0.5);


[yse, xse] = euler(y_der, 0, 0.5, y0, h);

[ys2, xs2] = runge_kutta_2nd(y_der, 0, 0.5, y0, h);

[xs4, ys4] = runge_kutta_4th(y_der, 0, 0.5, y0, h)

% absolute relative error at y(0.5)
disp('Relative error of Euler')
disp(abs(1.7974425414-yse(end))/1.7974425414);
disp('Relative error of RK2')
disp(abs(1.7974425414-ys2(end))/1.7974425414)
disp('Relative error of RK4')
disp(abs(1.7974425414-ys4(end))/1.7974425414)


%% Question 2

y_diff = @(x,y) x^2 - y - 2;
y_act = @(x) x^2 - 2*x - 8*exp((-x-2));

a = -2; 
b = 3;

n = 10;
h = (b-a)/n;
[yse, xse] = euler(y_diff, a, b, 0, h);
[ys2, xs2]= runge_kutta_2nd(y_diff, a, b, 0, h);
[xs4, ys4] = runge_kutta_4th(y_diff, a, b, 0, h);

acts = [];
for i=xse
    acts(end+1) = y_act(i);
end
    
hold on
plot(xse, yse)
plot(xse, ys2)
plot(xse, ys4)
plot(xse, acts)
legend('Euler','Runge Kutta 2','Runge Kutta 4','Actual')
%%
n = 20;
h = (b-a)/n;
[yse, xse] = euler(y_diff, a, b, 0, h);
[ys2, xs2]= runge_kutta_2nd(y_diff, a, b, 0, h);
[xs4, ys4] = runge_kutta_4th(y_diff, a, b, 0, h);

acts = [];
for i=xse
    acts(end+1) = y_act(i);
end
    
hold on
plot(xse, yse)
plot(xse, ys2)
plot(xse, ys4)
plot(xse, acts)
legend('Euler','Runge Kutta 2','Runge Kutta 4','Actual')

%%

n = 50;
h = (b-a)/n;
[yse, xse] = euler(y_diff, a, b, 0, h);
[ys2, xs2]= runge_kutta_2nd(y_diff, a, b, 0, h);
[xs4, ys4] = runge_kutta_4th(y_diff, a, b, 0, h);

acts = [];
for i=xse
    acts(end+1) = y_act(i);
end
    
hold on
plot(xse, yse)
plot(xse, ys2)
plot(xse, ys4)
plot(xse, acts)
legend('Euler','Runge Kutta 2','Runge Kutta 4','Actual')

