function [res]  = trapezoidal(f, a, b)
    h = b - a;
    res = h/2*(f(a)+f(b));
end