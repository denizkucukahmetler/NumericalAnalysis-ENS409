function [ys,xs] = euler(f, a, b, y0, h )


    %h = (b-a)/n;
    n = (b-a)/h;
    x = a;
    y = y0;
    xs = [x];
    ys = [y];
    
    for i=1:n
        y = y+h*f(x,y);
        x =a+i*h;
        xs(end+1) = x;
        ys(end+1) = y;
    end


end