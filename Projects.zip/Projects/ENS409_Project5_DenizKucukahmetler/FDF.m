function [diff] = FDF(f, h, x)
    diff = (f(x+h)-f(x))/h;
end