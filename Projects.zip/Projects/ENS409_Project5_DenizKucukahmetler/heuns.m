function [xs, ys] = heuns(f, a, y0, b, n, h)


    x = a;
    y = y0;
    xs = [x];
    ys = [y];
    for i=1:n
        k1 = f(x,y);
        k2 = f(x+h, y+(k1*h));
        x = x+h*k2;
        y = y + 0.5*(k1+k2)*h;
        xs(end+1) = x;
        ys(end+1) = y;
    end


end