function [approximation]  = Hermite(x,xs,fxs,fx_der) 

H2n = zeros(2*length(xs),1);
for i = 0:length(xs)-1
    
    H2n(2*i+1) = xs(i+1);
    H2n(2*i+2) = xs(i+1);
    
    Q(2*i+1,1) = fxs(i+1);
    Q(2*i+2,1) = fxs(i+1);
    Q(2*i+2,2) = fx_der(i+1);
    if i ~= 0
        num = Q(2*i+1,1)-Q(2*i,1);
        denom = H2n(2*i+1)-H2n(2*i);
        Q(2*i+1,2) = (num)/(denom);
    end
end

k = 2*(length(xs)-1)+1;

for i = 2:k
    for j = 2:i
        num = Q(i+1,j)-Q(i,j);
        denom = H2n(i+1)-H2n(i-j+1);
        Q(i+1,j+1) = (num)/(denom);
    end
end

sum = 0;
for i = 1:k
    mul = 1;
    for j = 1:(i+1)/2
        mul = mul*((x-xs(j))^2);
    end
    
    if rem(i+1,2) == 0
        mul = mul/(x-xs(j));
    end
    
    mul = mul*Q(i+1,i+1);
    
    sum = sum+mul;
end
approximation = Q(1,1)+sum;


end