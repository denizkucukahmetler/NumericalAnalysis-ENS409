%% Question 1

format long;
f = @(x) 3*x*exp(x) - exp(2*x);
x = [1 1.05 1.07 1.09 1.2 1.23];
fx = [0.76579 0.83543 0.85893 0.87956 0.92924 0.91952];
fx_der = [1.5316 1.2422 1.1056 0.95608 -0.13358 -0.52159];
N = length(x);

point = 1.03; 
f_pt = f(point);

approx_Lagrange = Lagrange(N, x, fx, point);
err_lgr = f_pt - approx_Lagrange;
approx_Newtons = Newtons(N, x, fx, point);
err_nwt =  f_pt - approx_Newtons;
approx_Hermite = Hermite(point, x, fx, fx_der);
err_h =  f_pt - approx_Hermite;
% Abs Errors 
disp("Exact value of f(1.03) "+num2str(f_pt, 16));
disp("Approximation found by Lagrange "+num2str(approx_Lagrange, 16));
disp("Absolute Error for Lagrange "+num2str(err_lgr, 16));
disp("Approximation found by Newtons "+num2str(approx_Newtons, 16));
disp("Absolute Error for Newtons "+num2str(err_nwt, 16));
disp("Approximation found by Hermite "+num2str(approx_Hermite, 16));
disp("Absolute Error for Hermite "+num2str(err_h, 16));

%% Question 2

range = [];
for i=-5:0.01:5
    range(end+1) = i;
end


syms x;
f = 1/(1+x^2);
f_der = diff(f);

n1 = linspace(-5,5,2);
n5 = linspace(-5,5,6);
n10 = linspace(-5,5,11);

fn1 = [];
fn1_der = [];
for i = 1:2
    x = n1(i);
    fn1(end+1) = subs(f);
    fn1_der(end+1) = subs(f_der);
    
end

fn5 = [];
fn5_der = [];
for i = 1:6
    x = n5(i);
    fn5(end+1) = subs(f);
    fn5_der(end+1) = subs(f_der);
end

fn10 = [];
fn10_der = [];
for i = 1:11
    x = n10(i);
    fn10(end+1) = subs(f);
    fn10_der(end+1) = subs(f_der);
end

pts_fx = [];
for i=1:length(range)
    x = range(i);
    pts_fx(end+1) = subs(f);
end



%% Approximate n = 1 for 3 methods
pts_lgr = [];
pts_nwt = [];
pts_hermite = [];
N = 2;
x = n1;
fx = fn1;
f_der = fn1_der;
for i=1:length(range)
    pts_lgr(end+1) = Lagrange(N, x, fx, range(i));
end

for i=1:length(range)
    pts_nwt(end+1) = Newtons(N, x, fx, range(i));
end


for i=1:length(range)
    pts_hermite(end+1) = Hermite(range(i), x, fx, f_der); %point, x, fx, fx_der
end




figure
hold on
x = n1;
scatter(n1,subs(f),'*','blue');
plot(range, pts_lgr,'LineWidth',5);
plot(range, pts_nwt,'LineWidth',2);
plot(range, pts_hermite);
plot(range, pts_fx);
legend('data points','Lagrange','Newtons','Hermite', 'f(x)')


%% Approximate n = 5 for 3 methods


pts_lgr = [];
pts_nwt = [];
pts_hermite = [];
N = 5;
x = n5;
fx = fn5;
f_der = fn5_der;
for i=1:length(range)
    pts_lgr(end+1) = Lagrange(N, x, fx, range(i));
end

for i=1:length(range)
    pts_nwt(end+1) = Newtons(N, x, fx, range(i));
end


for i=1:length(range)
    [pts_hermite(end+1)] = Hermite(range(i), x, fx, f_der); %point, x, fx, fx_der
end

figure
hold on
x = n5;
scatter(n5,subs(f),'*','blue','LineWidth',5);
plot(range, pts_lgr,'LineWidth',5);
plot(range, pts_nwt,'LineWidth',2);
plot(range, pts_hermite);
plot(range, pts_fx);
legend('data points','Lagrange','Newtons','Hermite', 'f(x)')

hold off


%% Approximate n = 10 for 3 methods
pts_lgr = [];
pts_nwt = [];
pts_hermite = [];
N = 11;
x = n10;
fx = fn10;
f_der = fn10_der;
for i=1:length(range)
    pts_lgr(end+1) = Lagrange(N, x, fx, range(i));
end

for i=1:length(range)
    pts_nwt(end+1) = Newtons(N, x, fx, range(i));
end


for i=1:length(range)
    [pts_hermite(end+1)] = Hermite(range(i), x, fx, f_der); %point, x, fx, fx_der
end

figure
hold on
x = n10;
scatter(n10,subs(f),'*','blue','LineWidth',5);
plot(range, pts_lgr,'LineWidth',5);
plot(range, pts_nwt,'LineWidth',2);
plot(range, pts_hermite);
plot(range, pts_fx);
legend('data points','Lagrange','Newtons','Hermite', 'f(x)')

hold off




%% Question 3

syms x;
f = sqrt(1+x^2);
f_der = diff(f);

xs = [];
n = 10;
for k = 1:n+1
    xs(end+1) = -1 + 2*(k-1)/n;
end 


fx = [];
fx_der = [];
for i = 1:11
    x = xs(i);
    fx(end+1) = subs(f);
    fx_der(end+1) = subs(f_der);
end

range = linspace(-1,1,41);

% n = 5
pts_lgr = [];
pts_nwt = [];
pts_hermite = [];

N = 6;

for i=1:length(range)
    pts_lgr(end+1) = Lagrange(N, xs(1:6), fx(1:6), range(i));
end

for i=1:length(range)
    pts_nwt(end+1) = Newtons(N, xs(1:6), fx(1:6), range(i));
end


for i=1:length(range)
    [pts_hermite(end+1)] = Hermite(range(i), xs(1:5), fx(1:5), fx_der(1:5)); %point, x, fx, fx_der
end


figure
hold on
x = xs(1:6);
scatter(x,subs(f),'*','blue','LineWidth',5);
plot(range, pts_lgr,'LineWidth',5);
plot(range, pts_nwt,'LineWidth',2);
plot(range, pts_hermite);
legend('data points','Lagrange','Newtons','Hermite')

hold off

% Calculate the error for n = 5
err_lgr = [];
err_nwt = [];
err_hermite = [];

for i=1:length(range)
    x = range(i);
    err_lgr(end+1) = subs(f) - pts_lgr(i);
    err_nwt(end+1) = subs(f) - pts_nwt(i);
    err_hermite(end+1) = subs(f) - pts_hermite(i);
end


% n = 10
pts_lgr = [];
pts_nwt = [];
pts_hermite = [];

N = 11;

for i=1:length(range)
    pts_lgr(end+1) = Lagrange(N, xs, fx, range(i));
end

for i=1:length(range)
    pts_nwt(end+1) = Newtons(N, xs, fx, range(i));
end


for i=1:length(range)
    [pts_hermite(end+1)] = Hermite(range(i), xs, fx, fx_der); %point, x, fx, fx_der
end

figure
hold on
x = xs;
scatter(x,subs(f),'*','blue','LineWidth',5);
plot(range, pts_lgr,'LineWidth',5);
plot(range, pts_nwt,'LineWidth',2);
plot(range, pts_hermite);
legend('data points','Lagrange','Newtons','Hermite')

hold off

% Calculate the error for n = 10
err_lgr5 = [];
err_nwt5 = [];
err_hermite5 = [];

for i=1:length(range)
    x = range(i);
    err_lgr5(end+1) = subs(f) - pts_lgr(i);
    err_nwt5(end+1) = subs(f) - pts_nwt(i);
    err_hermite5(end+1) = subs(f) - pts_hermite(i);
end

%% Plot Errors 

figure
hold on
bar(err_lgr, 'LineWidth',4);
bar(err_lgr5);
legend('Lagrange Error for n=5','Lagrange Error for n=10')

figure
hold on
bar(err_nwt,  'LineWidth',4);
bar(err_nwt5);
legend('Newtons Error for n=5','Newtons Error for n=10')

figure
hold on
bar(err_hermite,  'LineWidth',4);
bar(err_hermite5);
legend('Hermite Error for n=5','Hermite Error for n=10')





%% Question 3 for different xk

syms x;
f = sqrt(1+x^2);
f_der = diff(f);

xs = [];
n = 10;
for k = 1:n+1
    xs(end+1) =  cos(2*(k-1)/n);
end 


fx = [];
fx_der = [];
for i = 1:11
    x = xs(i);
    fx(end+1) = subs(f);
    fx_der(end+1) = subs(f_der);
end

range = linspace(-1,1,41);

% n = 5
pts_lgr = [];
pts_nwt = [];
pts_hermite = [];

N = 6;

for i=1:length(range)
    pts_lgr(end+1) = Lagrange(N, xs(1:6), fx(1:6), range(i));
end

for i=1:length(range)
    pts_nwt(end+1) = Newtons(N, xs(1:6), fx(1:6), range(i));
end


for i=1:length(range)
    [pts_hermite(end+1)] = Hermite(range(i), xs(1:5), fx(1:5), fx_der(1:5)); %point, x, fx, fx_der
end


figure
hold on
x = xs(1:6);
scatter(x,subs(f),'*','blue','LineWidth',5);
plot(range, pts_lgr,'LineWidth',5);
plot(range, pts_nwt,'LineWidth',2);
plot(range, pts_hermite);
legend('data points','Lagrange','Newtons','Hermite')

% Calculate the error for n = 5
err_lgr = [];
err_nwt = [];
err_hermite = [];

for i=1:length(range)
    x = range(i);
    err_lgr(end+1) = subs(f) - pts_lgr(i);
    err_nwt(end+1) = subs(f) - pts_nwt(i);
    err_hermite(end+1) = subs(f) - pts_hermite(i);
end


% n = 10
pts_lgr = [];
pts_nwt = [];
pts_hermite = [];

N = 11;

for i=1:length(range)
    pts_lgr(end+1) = Lagrange(N, xs, fx, range(i));
end

for i=1:length(range)
    pts_nwt(end+1) = Newtons(N, xs, fx, range(i));
end


for i=1:length(range)
    [pts_hermite(end+1)] = Hermite(range(i), xs, fx, fx_der); %point, x, fx, fx_der
end

% Calculate the error for n = 10
err_lgr5 = [];
err_nwt5 = [];
err_hermite5 = [];

for i=1:length(range)
    x = range(i);
    err_lgr5(end+1) = subs(f) - pts_lgr(i);
    err_nwt5(end+1) = subs(f) - pts_nwt(i);
    err_hermite5(end+1) = subs(f) - pts_hermite(i);
end

figure
hold on
x = xs;
scatter(x,subs(f),'*','blue','LineWidth',5);
plot(range, pts_lgr,'LineWidth',5);
plot(range, pts_nwt,'LineWidth',2);
plot(range, pts_hermite);
legend('data points','Lagrange','Newtons','Hermite')

% Plot Errors 

figure
hold on
plot(err_lgr);
plot(err_lgr5);
legend('Lagrange Error for n=5','Lagrange Error for n=10')

figure
hold on
plot(err_nwt);
plot(err_nwt5);
legend('Newtons Error for n=5','Newtons Error for n=10')

figure
hold on
plot(err_hermite);
plot(err_hermite5);
legend('Hermite Error for n=5','Hermite Error for n=10')

