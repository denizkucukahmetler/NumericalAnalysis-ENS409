function [approximation] = Newtons(N, x, fx, point)


d = zeros(N,N);
for i=1:N
    d(i,1) = fx(i);
end 

for k=2:N
    for i = 1:N-k+1
        d(i,k) = (d(i+1,k-1)-d(i,k-1))/(x(i+k-1)-x(i));
    end
   
end

approximation = 0;
for i=1:N
   mul = 1;
   for j=1:i-1
       mul = mul * (point-x(j));
   end
   approximation = approximation + d(1,i) * mul;
end

