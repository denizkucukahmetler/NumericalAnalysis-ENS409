function approximation = Lagrange(N, xs, fx, point)

 

approximation = 0;


for k=1:N
    Lx = L(N,xs,point,k);
    approximation = approximation + fx(k)*Lx;
end

end


function L_poly = L(N,xs,point,k)

num = 1;
denom = 1;
for i = 1:N
        if k ~= i
            num = num * (point - xs(i));
            denom = denom * (xs(k) - xs(i));
        end
end
L_poly = num/denom;

end