%% 25% test, 75% train
data = load('proj3data.mat');
x = data.x;
y = data.y;
data_xy = [x;y];
test_prop = 0.25;
N = length(data_xy(1,:));
tf = false(N,1);   % create logical index vector
tf(1:round(test_prop*N)) = true  ;   
tf = tf(randperm(N)) ;  % randomise order

dataTesting= data_xy(:,tf);
dataTraining = data_xy(:,~tf);

test_X = dataTesting(1,:);
test_Y =  dataTesting(2,:);
train_X = dataTraining(1,:);
train_Y = dataTraining(2,:);
train_size = length(train_X);


%% Part 1

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   fit the line %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%find a1
num = 0;
denom = 0;
sum1 = 0; 
for i=1:train_size
    sum1 = sum1 + train_X(i)*train_Y(i);
end

sum1 = train_size*sum1;

sum2 = 0;
sum2 = sum(train_X)*sum(train_Y);
num = sum1-sum2;

sum3 = 0;
for i=1:train_size
    sum3 = sum3 + (train_X(i))^2;
end
sum3 = train_size*sum3;

sum4 = sum(train_X)^2;

denom = sum3 - sum4;

a1 = num/denom;

%find a0
a0 = ( sum(train_Y)-a1*sum(train_X) )/train_size;

y = @(x) a1*x + a0;

%plot the line and the data
figure

scatter(train_X, train_Y);
hold on
fplot(y,[-1.5,1.5]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  find r %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sum1 = train_size *train_X * train_Y';
sum2 = sum(train_X)*sum(train_Y);
num = sum1-sum2;
denom = sqrt(train_size*sum(train_X.^2) - sum(train_X)^2) * sqrt(train_size*sum(train_Y.^2) - sum(train_Y)^2);;

r = num/denom;
disp("Correlation coefficient (r) is "+ num2str(r,16)+".");

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   explained original uncertainty   %%%%%%%%%%%%%%%%%%%%
uncertainty = r^2;
disp("Explained uncertainty by linear regression: "+num2str(uncertainty, 16)+ ".");

%% Part 2
%n = [2,5,10,30];

%%%%%%%%%%%%%%%%%%%%%%% n = 2 %%%%%%%%%%%%%%%%%%%%%%%%%
n=2;
a = poly_regression(train_X, train_Y,n);
b = polyfit(train_X, train_Y, n);
syms x;
y2 = 0;
yp2 = 0;
for i=n+1:-1:1
    y2 = y2 + a(i)*x^(i-1);
    yp2 = yp2 + b(n+2-i)*x^(i-1);
end

figure
scatter(train_X, train_Y);
hold on
fplot(y2,[-1.5,1.5], 3);
fplot(yp2,[-1.5,1.5]);
legend(['data'],['Yn'],['Yp']);

%find the errors
errors_2 = zeros(train_size,1);
errors_p2 = zeros(train_size,1);
syms x;
for i=1:train_size
    x = train_X(i);
    errors_2(i) = abs(train_Y(i) - subs(y2));
    errors_p2(i) = abs(train_Y(i) - subs(yp2));
end

disp('n = 2');
%Absolute Error
max_2 = max(errors_2);
max_p2 = max(errors_p2);
disp("Maximum absolute error of approximation yn "+num2str(max_2,16));
disp("Maximum absolute error of yp "+num2str(max_p2,16));

%Relative Error
idx_x = find(errors_2 == max_2);
idx_xp = find(errors_p2 == max_p2);

r_err = abs(max_2/train_X(idx_x));
r_perr = abs(max_p2/train_X(idx_xp));

disp("Maximum relative error of approximation yn "+num2str(r_err,16));
disp("Maximum relative error of yp "+num2str(r_perr,16));

%%
%%%%%%%%%%%%%%%%%%%%%%% n = 5 %%%%%%%%%%%%%%%%%%%%%%%%%

n=5;
a = poly_regression(train_X, train_Y,n);
b = polyfit(train_X, train_Y, n);
syms x;
y5 = 0;
yp5 = 0;
for i=n+1:-1:1
    y5 = y5 + a(i)*x^(i-1);
    yp5 = yp5 + b(n+2-i)*x^(i-1);
end

figure
scatter(train_X, train_Y);
hold on
fplot(y5,[-1.5,1.5]);
fplot(yp5,[-1.5,1.5]);
legend(['data'],['Yn'],['Yp']);

%find the errors
errors_5 = zeros(train_size,1);
errors_p5 = zeros(train_size,1);
syms x;
for i=1:train_size
    x = train_X(i);
    errors_5(i) = abs(train_Y(i) - subs(y5));
    errors_p5(i) = abs(train_Y(i) - subs(yp5));
end

%Absolute Error
max_5 = max(errors_5);
max_p5 = max(errors_p5);
disp('n = 5');
disp("Maximum absolute error of approximation yn "+num2str(max_5,16));
disp("Maximum absolute error of yp "+num2str(max_p5,16));

%Relative Error
idx_x = find(errors_5 == max_5);
idx_xp = find(errors_p5 == max_p5);

r_err = abs(max_5/train_X(idx_x));
r_perr = abs(max_p5/train_X(idx_xp));

disp("Maximum relative error of approximation yn "+num2str(r_err,16));
disp("Maximum relative error of yp "+num2str(r_perr,16));

%%
%%%%%%%%%%%%%%%%%%%%%%% n = 10 %%%%%%%%%%%%%%%%%%%%%%%%%

n=10;
a = poly_regression(train_X, train_Y,n);
b = polyfit(train_X, train_Y, n);
syms x;
y10 = 0;
yp10 = 0;
for i=n+1:-1:1
    y10 = y10 + a(i)*x^(i-1);
    yp10 = yp10 + b(n+2-i)*x^(i-1);
end

figure
scatter(train_X, train_Y);
hold on
fplot(y10,[-1.5,1.5]);
fplot(yp10,[-1.5,1.5]);
legend(['data'],['Yn'],['Yp']);



%find the errors
errors_10 = zeros(train_size,1);
errors_p10 = zeros(train_size,1);
syms x;
for i=1:train_size
    x = train_X(i);
    errors_10(i) = abs(train_Y(i) - subs(y10));
    errors_p10(i) = abs(train_Y(i) - subs(yp10));
end


disp('n = 10');
%Absolute Error
max_10 = max(errors_10);
max_p10 = max(errors_p10);
disp("Maximum absolute error of approximation yn "+num2str(max_10,16));
disp("Maximum absolute error of yp "+num2str(max_p10,16));

%Relative Error
idx_x = find(errors_10 == max_10);
idx_xp = find(errors_p10 == max_p10);

r_err = abs(max_10/train_X(idx_x));
r_perr = abs(max_p10/train_X(idx_xp));

disp("Maximum relative error of approximation yn "+num2str(r_err,16));
disp("Maximum relative error of yp "+num2str(r_perr,16));

%%
%%%%%%%%%%%%%%%%%%%%%%% n = 30 %%%%%%%%%%%%%%%%%%%%%%%%%

n=30;
a = poly_regression(train_X, train_Y,n);
b = polyfit(train_X, train_Y, n);
syms x;
y30 = 0;
yp30 = 0;
for i=n+1:-1:1
    y30 = y30 + a(i)*x^(i-1);
    yp30 = yp30 + b(n+2-i)*x^(i-1);
end

figure
scatter(train_X, train_Y);
hold on
fplot(y30,[-1.5,1.5]);
fplot(yp30,[-1.5,1.5]);
legend(['data'],['Yn'],['Yp']);

%find the errors
errors_30 = zeros(train_size,1);
errors_p30 = zeros(train_size,1);

syms x;
for i=1:train_size
    x = train_X(i);
    errors_30(i) = abs(train_Y(i) - subs(y30));
    errors_p30(i) = abs(train_Y(i) - subs(yp30));
end


disp('n = 30');
%Absolute Error
max_30 = max(errors_30);
max_p30 = max(errors_p30);
disp("Maximum absolute error of approximation yn "+num2str(max_30,16));
disp("Maximum absolute error of yp "+num2str(max_p30,16));

%Relative Error
idx_x = find(errors_30 == max_30);
idx_xp = find(errors_p30 == max_p30);

r_err = abs(max_30/train_X(idx_x));
r_perr = abs(max_p30/train_X(idx_xp));

disp("Maximum relative error of approximation yn "+num2str(r_err,16));
disp("Maximum relative error of yp "+num2str(r_perr,16));



%% Part 3

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   fit the line %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ln_train_X = (train_X);
ln_train_Y = log(train_Y);
%find a1


num = 0;
denom = 0;
sum1 = 0; 
for i=1:train_size
    sum1 = sum1 + train_X(i)*train_Y(i);
end

sum1 = train_size*sum1;

sum2 = 0;
sum2 = sum(train_X)*sum(train_Y);
num = sum1-sum2;

sum3 = 0;
for i=1:train_size
    sum3 = sum3 + (train_X(i))^2;
end
sum3 = train_size*sum3;

sum4 = sum(train_X)^2;

denom = sum3 - sum4;

a1 = num/denom;

%find a0
a0 = ( sum(train_Y)-a1*sum(train_X) )/train_size;


y_exp = @(x) a0*exp(a1*x);

%plot the line and the data
figure
scatter(train_X, train_Y);
hold on

fplot(y_exp,[-1.5,1.5]);

%find the errors

%find the errors
errors_30 = zeros(train_size,1);
errors_p30 = zeros(train_size,1);

syms x;
for i=1:train_size
    x = train_X(i);
    errors_30(i) = abs(train_Y(i) - subs(y_exp));
end


disp('exponential y');
%Absolute Error
max_30 = max(errors_30);
disp("Maximum absolute error of approximation yn "+num2str(max_30,16));

%Relative Error
idx_x = find(errors_30 == max_30);

r_err = abs(max_30/train_X(idx_x));

disp("Maximum relative error of approximation yn "+num2str(r_err,16));



%% Part 4
test_size = length(test_X);
errors = zeros(6,test_size);

%try the model found in Part 1
syms x;
for i=1:test_size
    x = test_X(i);
    errors(1,i) = abs(test_Y(i) - subs(y));
end

%try the model found in Part 2 (n = 2,5,10,30)
for i=1:test_size
    x = test_X(i);
    errors(2,i) = abs(test_Y(i) - subs(y2));
end
for i=1:test_size
    x = test_X(i);
    errors(3,i) = abs(test_Y(i) - subs(y5));
end
for i=1:test_size
    x = test_X(i);
    errors(4,i) = abs(test_Y(i) - subs(y10));
end
for i=1:test_size
    x = test_X(i);
    errors(5,i) = abs(test_Y(i) - subs(y30));
end

%try the model found in Part 3
for i=1:test_size
    x = test_X(i);
    errors(6,i) = abs(test_Y(i) - subs(y_exp));
end
%plot the errors
figure
hold on
for i=1:6
    plot(errors(i,:));
end
legend(['n=1'],['n=2'],['n=5'],['n=10'],['n=30'],['using exponential function']);
