function [a]=poly_regression(X,Y,order)

n = length(X);
m = zeros(order+1,order+1);
m(1,1) = n;

for i = 1:(order+1)
    for j = 1:(order+1)
        if i+j > 2
        expon = i+j-2;
        m(i,j) = sum(X.^expon);
        end
    end 
end

y_m = zeros(order+1,1);
for i = 1:(order+1)
    y_m(i) = sum( (X.^(i-1)) * Y');
end

a = linsolve(m,y_m);