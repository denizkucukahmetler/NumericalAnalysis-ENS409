function [root, error, itr] = ModifiedRegulaFalsi(f, a, b, criterion, stopping_info)
    

% criterion == 0 -> error threshold
% criterion == 1 -> # of iterations
itr = 0;
prev_a = a;
prev_b = b;
counter_a = 0;
counter_b = 0;
if criterion 
    for i=1:stopping_info
        itr = itr + 1;
        x = a + (f(a)*a - f(a)*b)/(f(b) - f(a)); 
        if sign(f(x)) == sign(f(a))
            a = x;
        else
            b = x;
        end 
        if a==prev_a
            counter_a = counter_a+1;
            if counter_a == 2
                a = a/2;
                counter_a = 0;
            end
        elseif b==prev_b
            counter_b = counter_b+1;
            if counter_b == 2
                b = b/2;
                counter_b = 0;
            end
        end
        prev_a = a;
        prev_b = b;
    end
    
    root = x;
else
    x = a + (f(a)*a - f(a)*b)/(f(b) - f(a));
    while abs(f(x)) > stopping_info
        itr = itr + 1;
        if sign(f(x)) == sign(f(a))
            a = x;
        else
            b = x;
        end 
        x = a + (f(a)*a - f(a)*b)/(f(b) - f(a));
         if a==prev_a
            counter_a = counter_a+1;
            if counter_a == 2
                a = a/2;
                counter_a = 0;
            end
        elseif b==prev_b
            counter_b = counter_b+1;
            if counter_b == 2
                b = b/2;
                counter_b = 0;
            end
        end
        prev_a = a;
        prev_b = b;
    end
    
    root = x;
end

error = abs(f(root));

end
