function [root, error, itr] = Bisection(f, a, b, criterion, stopping_info)
    

% criterion == 0 -> error threshold
% criterion == 1 -> # of iterations
itr = 0;
if criterion 
    for i=1:stopping_info
        itr = itr + 1;
        c = (a+b)/2;
        if f(a)*f(c) < 0
            b = c;
        elseif f(a)*f(c) > 0
            a = c;
        else
            root = c;
            break
        end
    end
    root = c;
else
    c = (a+b)/2;
    while abs(f(c)) > stopping_info
        itr = itr + 1;
        if f(a)*f(c) < 0
            b = c;
        elseif f(a)*f(c) > 0
            a = c;
        else
            root = c;
            break
        end
        c = (a+b)/2;
    end
    root = c;
end

error = abs(f(c));

end
