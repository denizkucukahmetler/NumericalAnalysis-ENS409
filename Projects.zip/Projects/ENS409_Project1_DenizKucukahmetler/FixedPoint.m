function [root, error, itr] = FixedPoint(f,  x0, criterion, stopping_info)
    

% criterion == 0 -> error threshold
% criterion == 1 -> # of iterations
itr = 0;
x = x0;
if criterion 
    for i=1:stopping_info
        x = f(x);
        itr = itr + 1;
    end
    root = x;
else
    while abs(f(x)-x) > stopping_info
        disp(num2str(x, 16));
        x = f(x);
        itr = itr + 1;
        
    end
    root = x;
end

error = abs(f(root)-x);

end

