function [root, error, itr] = RegulaFalsi(f, a, b, criterion, stopping_info)
    

% criterion == 0 -> error threshold
% criterion == 1 -> # of iterations
itr = 0;
if criterion 
    for i=1:stopping_info
        itr = itr + 1;
        x = a + (f(a)*a - f(a)*b)/(f(b) - f(a)); 
        if sign(f(x)) == sign(f(a))
            a = x;
        else
            b = x;
        end 
    end
    root = x;
else
    x = a + (f(a)*a - f(a)*b)/(f(b) - f(a));
    while abs(f(x)) > stopping_info
        itr = itr + 1;
        if sign(f(x)) == sign(f(a))
            a = x;
        else
            b = x;
        end 
        x = a + (f(a)*a - f(a)*b)/(f(b) - f(a));
    end
    root = x;
end

error = abs(f(root));

end


