function [root, error, itr] = Secant(f, a, b, criterion, stopping_info)
    

% criterion == 0 -> error threshold
% criterion == 1 -> # of iterations
itr = 0;
pn = b;
pn_prev = a;
if criterion 
    for i=1:stopping_info
        itr = itr + 1;
        pn_temp = pn;
        pn = pn + (f(pn)*pn_prev - f(pn)*pn)/(f(pn) - f(pn_prev));
        pn_prev = pn_temp;
    end
    root = pn;
else
    while abs(f(pn)) > stopping_info
        itr = itr + 1;
        pn_temp = pn;
        pn = pn + (f(pn)*pn_prev - f(pn)*pn)/(f(pn) - f(pn_prev));
        pn_prev = pn_temp; 
    end
    root = pn;
end

error = abs(f(root));

end
