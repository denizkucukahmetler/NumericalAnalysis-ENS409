%% Question 1

f = @(x) 4*x^3-8*x^2+3*x-10;
f_drv =  @(x) 12*x^2-16*x+3;
g = @(x) (-4*x^3+8*x^2+10)/3; % did not work
g = @(x) (-1*sqrt((10-4*x^3-3*x))/8); %did not work
g = @(x) ((8*x^2-3*x+10)/4)^(1/3); 
a = 1;
b = 3;
c = 2;
err = 10^-4;
[root, error, itr] = Bisection(f, a, b, 0, err);
disp("Root found by Bisection: "+num2str(root, 16))
disp("Error by Bisection: "+num2str(error, 16))
disp("Number of iterations by Bisection: "+num2str(itr, 16))
disp(' ');
[root, error, itr] = RegulaFalsi(f, a, b, 0, err);
disp("Root found by False Position: "+num2str(root, 16))
disp("Error by False Position: "+num2str(error, 16))
disp("Number of iterations by False Position: "+num2str(itr, 16))
disp(' ');
[root, error, itr] = ModifiedRegulaFalsi(f, a, b, 0, err);
disp("Root found by Modified False Position: "+num2str(root, 16))
disp("Error by Modified False Position: "+num2str(error, 16))
disp("Number of iterations by Modified False Position: "+num2str(itr, 16))
disp(' ');
[root, error, itr] = Secant(f, a, b, 0, err);
disp("Root found by Secant: "+num2str(root, 16))
disp("Error by Secant: "+num2str(error, 16))
disp("Number of iterations by Secant: "+num2str(itr, 16))
disp(' ');
[root, error, itr] = Newtons(f, f_drv, c, 0, err);
disp("Root found by Newtons: "+num2str(root, 16))
disp("Error by Newtons: "+num2str(error, 16))
disp("Number of iterations by Newtons: "+num2str(itr, 16))
disp(' ');
[root, error, itr] = FixedPoint(g, c, 0, err);
disp("Root found by Fixed Point: "+num2str(root, 16))
disp("Error by Fixed Point: "+num2str(error, 16))
disp("Number of iterations by Fixed Point: "+num2str(itr, 16))
%% Question 2
f = @(x) x^2-x-exp(-x);
f_drv = @(x) 2*x-1+exp(-x);
g = @(x) x^2-exp(-x);
g2 = @(x) sqrt(x+exp(-x));
a = 1;
b = 2;
c = 1.5;
iter = 6;
solution = fzero(f, 1.5);
[root, error, itr] = Bisection(f, a, b, 1, iter);
error = abs(solution - root)/solution;
disp("Root found by Bisection: "+num2str(root, 32))
disp("Error by Bisection: "+num2str(error, 32))
disp(' ');
[root, error, itr] = RegulaFalsi(f, a, b, 1, iter);
error = abs(solution - root)/solution;
disp("Root found by False Position: "+num2str(root, 32))
disp("Error by False Position: "+num2str(error, 32))
disp(' ');
[root, error, itr] = ModifiedRegulaFalsi(f, a, b, 1, iter);
error = abs(solution - root)/solution;
disp("Root found by Modified False Position: "+num2str(root, 32))
disp("Error by Modified False Position: "+num2str(error, 32))
disp(' ');
[root, error, itr] = Secant(f, a, b, 1, iter);
error = abs(solution - root)/solution;
disp("Root found by Secant: "+num2str(root, 32))
disp("Error by Secant: "+num2str(error, 32))
disp(' ');
[root, error, itr] = Newtons(f, f_drv, c, 1, iter);
error = abs(solution - root)/solution;
disp("Root found by Newtons: "+num2str(root, 32))
disp("Error by Newtons: "+num2str(error, 32))
disp(' ');
[root, error, itr] = FixedPoint(g2, c, 1, iter);
error = abs(solution - root)/solution;
disp("Root found by Fixed Point: "+num2str(root, 32))
disp("Error by Fixed Point: "+num2str(error, 32))

%% Question 3
f = @(x) exp(x^3)-8;
f_drv = @(x) 3*x^2*exp(x^3);
g = @(x) exp(x^3)-8+x;
a = 0;
b = 3;
c = 1.5;
solution = fzero(f, 1.5);
for iter=[10,50,100]
    disp("Number of iterations:"+ num2str(iter));
    disp(' ');
    [root, error, itr] = Bisection(f, a, b, 1, iter);
    disp("Root found by Bisection: "+num2str(root, 16))
    disp("Error by Bisection: "+num2str(error, 16))
    disp(' ');
    [root, error, itr] = RegulaFalsi(f, a, b, 1, iter);
    disp("Root found by False Position: "+num2str(root, 16))
    disp("Error by False Position: "+num2str(error, 16))
    disp(' ');
    [root, error, itr] = ModifiedRegulaFalsi(f, a, b, 1, iter);
    disp("Root found by Modified False Position: "+num2str(root, 16))
    disp("Error by Modified False Position: "+num2str(error, 16))
    disp(' ');
    [root, error, itr] = Secant(f, a, b, 1, iter);
    disp("Root found by Secant: "+num2str(root, 16))
    disp("Error by Secant: "+num2str(error, 16))
    disp(' ');
    [root, error, itr] = Newtons(f, f_drv, c, 1, iter);
    disp("Root found by Newtons: "+num2str(root, 16))
    disp("Error by Newtons: "+num2str(error, 16))
    disp(' ');
    [root, error, itr] = FixedPoint(f, c, 1, iter);
    disp("Root found by Fixed Point: "+num2str(root, 16))
    disp("Error by Fixed Point: "+num2str(error, 16))
    disp(' ');
end 
%% Question 4
f = @(x) 2*x.^2-x.^3+sin(x);
f_drv = @(x) 4*x-3*x.^2+cos(x);
g = @(x) sqrt((x^3+sin(x))/2);
g2 = @(x) (2*x^2+sin(x))^1/3;
g3 = @(x) asin(x^3-2*x^2);

%% first root [-1,-0.2]
roots = fzero(f, -1);
disp(' ');
disp('FIRST ROOT = -0.404612836030309')
disp(' ');
a = -1;
b = -0.2;
c = (a+b)/2;
err = 10^-6;

[root, error, itr] = Bisection(f, a, b, 0, err);
disp("Root found by Bisection: "+num2str(root, 16))
disp("Error by Bisection: "+num2str(error, 16))
disp(' ');
[root, error, itr] = RegulaFalsi(f, a, b, 0, err);
disp("Root found by False Position: "+num2str(root, 16))
disp("Error by False Position: "+num2str(error, 16))
disp(' ');
[root, error, itr] = ModifiedRegulaFalsi(f, a, b, 0, err);
disp("Root found by Modified False Position: "+num2str(root, 16))
disp("Error by Modified False Position: "+num2str(error, 16))
disp(' ');
[root, error, itr] = Secant(f, a, b, 0, err);
disp("Root found by Secant: "+num2str(root, 16))
disp("Error by Secant: "+num2str(error, 16))
disp(' ');
[root, error, itr] = Newtons(f, f_drv, c, 0, err);
disp("Root found by Newtons: "+num2str(root, 16))
disp("Error by Newtons: "+num2str(error, 16))
disp(' ');
[root, error, itr] = FixedPoint(g2, c, 0, err);
disp("Root found by Fixed Point: "+num2str(root, 16))
disp("Error by Fixed Point: "+num2str(error, 16))

%% second root [-0.2, 1]
roots = fzero(f, 0);
disp(' ');
disp('SECOND ROOT = 0')
disp(' ');
a = -0.2;
b = 1;
c = (a+b)/2;
[root, error, itr] = Bisection(f, a, b, 0, err);
disp("Root found by Bisection: "+num2str(root, 16))
disp("Error by Bisection: "+num2str(error, 16))
disp(' ');
[root, error, itr] = RegulaFalsi(f, a, b, 0, err);
disp("Root found by False Position: "+num2str(root, 16))
disp("Error by False Position: "+num2str(error, 16))
disp(' ');
[root, error, itr] = ModifiedRegulaFalsi(f, a, b, 0, err);
disp("Root found by Modified False Position: "+num2str(root, 16))
disp("Error by Modified False Position: "+num2str(error, 16))
disp(' ');
[root, error, itr] = Secant(f, a, b, 0, err);
disp("Root found by Secant: "+num2str(root, 16))
disp("Error by Secant: "+num2str(error, 16))
disp(' ');
[root, error, itr] = Newtons(f, f_drv, c, 0, err);
disp("Root found by Newtons: "+num2str(root, 16))
disp("Error by Newtons: "+num2str(error, 16))
disp(' ');
[root, error, itr] = FixedPoint(g, c, 0, err);
disp("Root found by Fixed Point: "+num2str(root, 16))
disp("Error by Fixed Point: "+num2str(error, 16))

%% third root [1, 3]
roots = fzero(f, 2);
disp(' ');
disp('THIRD ROOT = 2.174190120503632')
disp(' ');
a = 1;
b = 3;
c = (a+b)/2;
[root, error, itr] = Bisection(f, a, b, 0, err);
disp("Root found by Bisection: "+num2str(root, 16))
disp("Error by Bisection: "+num2str(error, 16))
disp(' ');
[root, error, itr] = RegulaFalsi(f, a, b, 0, err);
disp("Root found by False Position: "+num2str(root, 16))
disp("Error by False Position: "+num2str(error, 16))
disp(' ');
[root, error, itr] = ModifiedRegulaFalsi(f, a, b, 0, err);
disp("Root found by Modified False Position: "+num2str(root, 16))
disp("Error by Modified False Position: "+num2str(error, 16))
disp(' ');
[root, error, itr] = Secant(f, a, b, 0, err);
disp("Root found by Secant: "+num2str(root, 16))
disp("Error by Secant: "+num2str(error, 16))
disp(' ');
[root, error, itr] = Newtons(f, f_drv, c, 0, err);
disp("Root found by Newtons: "+num2str(root, 16))
disp("Error by Newtons: "+num2str(error, 16))
disp(' ');
[root, error, itr] = FixedPoint(g3, c, 0, err);
disp("Root found by Fixed Point: "+num2str(root, 16))
disp("Error by Fixed Point: "+num2str(error, 16))

